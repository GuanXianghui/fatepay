﻿Imports System.Security.Cryptography
Imports System.Text
Imports System.Collections.Specialized
Public Class DinpayToMer
    Inherits System.Web.UI.Page

    '功能：智付页面跳转同步通知页面
    '版本：3.0
    '日期：2013-08-01
    '说明：
    '以下代码仅为了方便商户安装接口而提供的样例具体说明以文档为准，商户可以根据自己网站的需要，按照技术文档编写。
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        '获取智付GET过来反馈信息
        '商号号
        Dim merchant_code As String = Trim(Request.Form("merchant_code").ToString())

        '通知类型
        Dim notify_type As String = Trim(Request.Form("notify_type").ToString())

        '通知校验ID
        Dim notify_id As String = Trim(Request.Form("notify_id").ToString())

        '接口版本
        Dim interface_version As String = Trim(Request.Form("interface_version").ToString())

        '签名方式
        Dim sign_type As String = Trim(Request.Form("sign_type").ToString())

        '签名
        Dim dinpaySign As String = Trim(Request.Form("sign").ToString())

        '商家订单号
        Dim order_no As String = Trim(Request.Form("order_no").ToString())

        '商家订单时间
        Dim order_time As String = Trim(Request.Form("order_time").ToString())

        '商家订单金额
        Dim order_amount As String = Trim(Request.Form("order_amount").ToString())

        '回传参数
        Dim extra_return_param As String = Trim(Request.Form("extra_return_param").ToString())

        '智付交易定单号
        Dim trade_no As String = Trim(Request.Form("trade_no").ToString())

        '智付交易时间
        Dim trade_time As String = Trim(Request.Form("trade_time").ToString())

        '交易状态 SUCCESS 成功  FAILED 失败
        Dim trade_status As String = Trim(Request.Form("trade_status").ToString())

        '银行交易流水号
        Dim bank_seq_no As String = Trim(Request.Form("bank_seq_no").ToString())


        '签名顺序按照参数名a到z的顺序排序，若遇到相同首字母，则看第二个字母，以此类推，
        '同时将商家支付密钥key放在最后参与签名，组成规则如下：
        '参数名1=参数值1&参数名2=参数值2&……&参数名n=参数值n&key=key值

        '组织订单信息
        Dim signStr As String = ""

        If bank_seq_no <> "" Then
            signStr = signStr + "bank_seq_no=" + bank_seq_no + "&"
        End If

        If extra_return_param <> "" Then
            signStr = signStr + "extra_return_param=" + extra_return_param + "&"
        End If

        signStr = signStr + "interface_version=V3.0" + "&"
        signStr = signStr + "merchant_code=" + merchant_code + "&"

        If notify_id <> "" Then
            signStr = signStr + "notify_id=" + notify_id + "&notify_type=page_notify&"
        End If

        signStr = signStr + "order_amount=" + order_amount + "&"
        signStr = signStr + "order_no=" + order_no + "&"
        signStr = signStr + "order_time=" + order_time + "&"
        signStr = signStr + "trade_no=" + trade_no + "&"
        signStr = signStr + "trade_status=" + trade_status + "&"

        If trade_time <> "" Then
            signStr = signStr + "trade_time=" + trade_time + "&"
        End If

        Dim key As String = "123456789a123456789_"
        signStr = signStr + "key=" + key

        Dim signInfo As String = signStr

        '将组装好的信息MD5签名
        Dim MD5 As New MD5CryptoServiceProvider()
        Dim sign As String = LCase(BitConverter.ToString(MD5.ComputeHash(Encoding.GetEncoding("gb2312").GetBytes(signInfo))).Replace("-", "")) '注意与支付签名不同  此处对String进行加密


        '比较智付返回的签名串与商家这边组装的签名串是否一致

        If dinpaySign = sign Then

            '验签成功
            '此处进行商户业务操作()
            '业务结束()
        Else
            '验签失败 业务结束
        End If

    End Sub

End Class