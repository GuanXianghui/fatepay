﻿Imports System.Security.Cryptography
Imports System.Text
Imports System.Collections.Specialized
Public Class _Default
    Inherits System.Web.UI.Page

    '功能：即时到账交易接口接入页
    '版本：3.0
    '日期：2013-08-01
    '说明：
    '以下代码只是为了方便商户测试而提供的样例代码，商户可以根据自己网站的需要，按照技术文档编写,
    '并非一定要使用该代码。该代码仅供学习和研究智付接口使用，仅为提供一个参考。
    ' ====================请求参数=======================
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try

            '参数编码字符集(必选)
            Dim input_charset1 As String = Trim(Request.Form("input_charset").ToString())
            '接口版本(必选)固定值:V3.0
            Dim interface_version1 As String = Trim(Request.Form("interface_version").ToString())
            '商家号（必填）
            Dim merchant_code1 As String = Trim(Request.Form("merchant_code").ToString())
            '后台通知地址(必填)
            Dim notify_url1 As String = Trim(Request.Form("notify_url").ToString())
            '定单金额（必填）
            Dim order_amount1 As String = Trim(Request.Form("order_amount").ToString())
            '商家定单号(必填)
            Dim order_no1 As String = Trim(Request.Form("order_no").ToString())
            '商家定单时间(必填)
            Dim order_time1 As String = Trim(Request.Form("order_time").ToString())
            '签名方式(必填)
            Dim sign_type1 As String = Trim(Request.Form("sign_type").ToString())
            '商品编号(选填)
            Dim product_code1 As String = Trim(Request.Form("product_code").ToString())
            '商品描述（选填）
            Dim product_desc1 As String = Trim(Request.Form("product_desc").ToString())
            '商品名称（必填）
            Dim product_name1 As String = Trim(Request.Form("product_name").ToString())
            '端口数量(选填)
            Dim product_num1 As String = Trim(Request.Form("product_num").ToString())
            '页面跳转同步通知地址(选填)
            Dim return_url1 As String = Trim(Request.Form("return_url").ToString())
            '业务类型(必填)
            Dim service_type1 As String = Trim(Request.Form("service_type").ToString())
            '商品展示地址(选填)
            Dim show_url1 As String = Trim(Request.Form("show_url").ToString())
            '公用业务扩展参数（选填）
            Dim extend_param1 As String = Trim(Request.Form("extend_param").ToString())
            '公用业务回传参数（选填）
            Dim extra_return_param1 As String = Trim(Request.Form("extra_return_param").ToString())
            '直联通道代码（选填）
            Dim bank_code1 As String = Trim(Request.Form("bank_code").ToString())
            '客户端IP（选填）
            Dim client_ip1 As String = Trim(Request.Form("client_ip").ToString())

            '注  new String(参数.getBytes("ISO-8859-1"),"此页面编码格式") 若为GBK编码 则替换UTF-8 为GBK
            If product_name1 <> "" Then
                product_name1 = product_name1
            End If
            If product_desc1 <> "" Then
                product_desc1 = product_desc1
            End If
            If extend_param1 <> "" Then
                extend_param1 = extend_param1
            End If
            If extra_return_param1 <> "" Then
                extra_return_param1 = extra_return_param1
            End If
            If product_code1 <> "" Then
                product_code1 = product_code1
            End If
            If return_url1 <> "" Then
                return_url1 = return_url1
            End If
            If show_url1 <> "" Then
                show_url1 = show_url1
            End If

            '签名顺序按照参数名a到z的顺序排序，若遇到相同首字母，则看第二个字母，以此类推，同时将商家支付密钥key放在最后参与签名，
            '组成规则如下：
            '参数名1=参数值1&参数名2=参数值2&……&参数名n=参数值n&key=key值
            Dim signSrc As String = ""

            '组织订单信息
            If bank_code1 <> "" Then
                signSrc = signSrc + "bank_code=" + bank_code1 + "&"
            End If
            If client_ip1 <> "" Then
                signSrc = signSrc + "client_ip=" + client_ip1 + "&"
            End If
            If extend_param1 <> "" Then
                signSrc = signSrc + "extend_param=" + extend_param1 + "&"
            End If
            If extra_return_param1 <> "" Then
                signSrc = signSrc + "extra_return_param=" + extra_return_param1 + "&"
            End If
            If input_charset1 <> "" Then
                signSrc = signSrc + "input_charset=" + input_charset1 + "&"
            End If
            If interface_version1 <> "" Then
                signSrc = signSrc + "interface_version=" + interface_version1 + "&"
            End If
            If merchant_code1 <> "" Then
                signSrc = signSrc + "merchant_code=" + merchant_code1 + "&"
            End If
            If notify_url1 <> "" Then
                signSrc = signSrc + "notify_url=" + notify_url1 + "&"
            End If
            If order_amount1 <> "" Then
                signSrc = signSrc + "order_amount=" + order_amount1 + "&"
            End If
            If order_no1 <> "" Then
                signSrc = signSrc + "order_no=" + order_no1 + "&"
            End If
            If order_time1 <> "" Then
                signSrc = signSrc + "order_time=" + order_time1 + "&"
            End If
            If product_code1 <> "" Then
                signSrc = signSrc + "product_code=" + product_code1 + "&"
            End If
            If product_desc1 <> "" Then
                signSrc = signSrc + "product_desc=" + product_desc1 + "&"
            End If
            If product_name1 <> "" Then
                signSrc = signSrc + "product_name=" + product_name1 + "&"
            End If
            If product_num1 <> "" Then
                signSrc = signSrc + "product_num=" + product_num1 + "&"
            End If
            If return_url1 <> "" Then
                signSrc = signSrc + "return_url=" + return_url1 + "&"
            End If
            If service_type1 <> "" Then
                signSrc = signSrc + "service_type=" + service_type1 + "&"
            End If
            If show_url1 <> "" Then
                signSrc = signSrc + "show_url=" + show_url1 + "&"
            End If


            '设置密钥
            Dim key As String = "123456789a123456789_"
            signSrc = signSrc + "key=" + key

            Dim singInfo As String = signSrc
            Response.Write("singInfo=" + singInfo + "<br>")

            '签名
            Dim MD5 As New MD5CryptoServiceProvider()
            Dim sign1 As String = LCase(BitConverter.ToString(MD5.ComputeHash(Encoding.GetEncoding("gb2312").GetBytes(singInfo))).Replace("-", ""))
            Response.Write("sign=" + sign1 + "<br>")


            sign.Value = sign1
            merchant_code.Value = merchant_code1
            bank_code.Value = bank_code1
            order_no.Value = order_no1
            order_amount.Value = order_amount1
            service_type.Value = service_type1
            input_charset.Value = input_charset1
            notify_url.Value = notify_url1
            interface_version.Value = interface_version1
            sign_type.Value = sign_type1
            order_time.Value = order_time1
            product_name.Value = product_name1
            client_ip.Value = client_ip1
            extend_param.Value = extend_param1
            extra_return_param.Value = extra_return_param1
            product_code.Value = product_code1
            product_desc.Value = product_desc1
            product_num.Value = product_num1
            return_url.Value = return_url1
            show_url.Value = show_url1

        Catch ex As Exception

        End Try
    End Sub

    Private Sub MD5CryptoServiceProvider(ByVal p1 As Object)
        Throw New NotImplementedException
    End Sub

End Class