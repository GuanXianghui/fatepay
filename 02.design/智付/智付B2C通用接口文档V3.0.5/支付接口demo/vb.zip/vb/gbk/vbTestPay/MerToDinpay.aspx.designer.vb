﻿'------------------------------------------------------------------------------
' <自动生成>
'     此代码由工具生成。
'
'     对此文件的更改可能会导致不正确的行为，并且如果
'     重新生成代码，这些更改将会丢失。 
' </自动生成>
'------------------------------------------------------------------------------

Option Strict On
Option Explicit On


Partial Public Class _Default

    '''<summary>
    '''dinpayForm 控件。
    '''</summary>
    '''<remarks>
    '''自动生成的字段。
    '''若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
    '''</remarks>
    Protected WithEvents dinpayForm As Global.System.Web.UI.HtmlControls.HtmlForm

    '''<summary>
    '''sign 控件。
    '''</summary>
    '''<remarks>
    '''自动生成的字段。
    '''若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
    '''</remarks>
    Protected WithEvents sign As Global.System.Web.UI.HtmlControls.HtmlInputHidden

    '''<summary>
    '''merchant_code 控件。
    '''</summary>
    '''<remarks>
    '''自动生成的字段。
    '''若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
    '''</remarks>
    Protected WithEvents merchant_code As Global.System.Web.UI.HtmlControls.HtmlInputHidden

    '''<summary>
    '''bank_code 控件。
    '''</summary>
    '''<remarks>
    '''自动生成的字段。
    '''若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
    '''</remarks>
    Protected WithEvents bank_code As Global.System.Web.UI.HtmlControls.HtmlInputHidden

    '''<summary>
    '''order_no 控件。
    '''</summary>
    '''<remarks>
    '''自动生成的字段。
    '''若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
    '''</remarks>
    Protected WithEvents order_no As Global.System.Web.UI.HtmlControls.HtmlInputHidden

    '''<summary>
    '''order_amount 控件。
    '''</summary>
    '''<remarks>
    '''自动生成的字段。
    '''若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
    '''</remarks>
    Protected WithEvents order_amount As Global.System.Web.UI.HtmlControls.HtmlInputHidden

    '''<summary>
    '''service_type 控件。
    '''</summary>
    '''<remarks>
    '''自动生成的字段。
    '''若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
    '''</remarks>
    Protected WithEvents service_type As Global.System.Web.UI.HtmlControls.HtmlInputHidden

    '''<summary>
    '''input_charset 控件。
    '''</summary>
    '''<remarks>
    '''自动生成的字段。
    '''若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
    '''</remarks>
    Protected WithEvents input_charset As Global.System.Web.UI.HtmlControls.HtmlInputHidden

    '''<summary>
    '''notify_url 控件。
    '''</summary>
    '''<remarks>
    '''自动生成的字段。
    '''若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
    '''</remarks>
    Protected WithEvents notify_url As Global.System.Web.UI.HtmlControls.HtmlInputHidden

    '''<summary>
    '''interface_version 控件。
    '''</summary>
    '''<remarks>
    '''自动生成的字段。
    '''若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
    '''</remarks>
    Protected WithEvents interface_version As Global.System.Web.UI.HtmlControls.HtmlInputHidden

    '''<summary>
    '''sign_type 控件。
    '''</summary>
    '''<remarks>
    '''自动生成的字段。
    '''若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
    '''</remarks>
    Protected WithEvents sign_type As Global.System.Web.UI.HtmlControls.HtmlInputHidden

    '''<summary>
    '''order_time 控件。
    '''</summary>
    '''<remarks>
    '''自动生成的字段。
    '''若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
    '''</remarks>
    Protected WithEvents order_time As Global.System.Web.UI.HtmlControls.HtmlInputHidden

    '''<summary>
    '''product_name 控件。
    '''</summary>
    '''<remarks>
    '''自动生成的字段。
    '''若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
    '''</remarks>
    Protected WithEvents product_name As Global.System.Web.UI.HtmlControls.HtmlInputHidden

    '''<summary>
    '''client_ip 控件。
    '''</summary>
    '''<remarks>
    '''自动生成的字段。
    '''若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
    '''</remarks>
    Protected WithEvents client_ip As Global.System.Web.UI.HtmlControls.HtmlInputHidden

    '''<summary>
    '''extend_param 控件。
    '''</summary>
    '''<remarks>
    '''自动生成的字段。
    '''若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
    '''</remarks>
    Protected WithEvents extend_param As Global.System.Web.UI.HtmlControls.HtmlInputHidden

    '''<summary>
    '''extra_return_param 控件。
    '''</summary>
    '''<remarks>
    '''自动生成的字段。
    '''若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
    '''</remarks>
    Protected WithEvents extra_return_param As Global.System.Web.UI.HtmlControls.HtmlInputHidden

    '''<summary>
    '''product_code 控件。
    '''</summary>
    '''<remarks>
    '''自动生成的字段。
    '''若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
    '''</remarks>
    Protected WithEvents product_code As Global.System.Web.UI.HtmlControls.HtmlInputHidden

    '''<summary>
    '''product_desc 控件。
    '''</summary>
    '''<remarks>
    '''自动生成的字段。
    '''若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
    '''</remarks>
    Protected WithEvents product_desc As Global.System.Web.UI.HtmlControls.HtmlInputHidden

    '''<summary>
    '''product_num 控件。
    '''</summary>
    '''<remarks>
    '''自动生成的字段。
    '''若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
    '''</remarks>
    Protected WithEvents product_num As Global.System.Web.UI.HtmlControls.HtmlInputHidden

    '''<summary>
    '''return_url 控件。
    '''</summary>
    '''<remarks>
    '''自动生成的字段。
    '''若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
    '''</remarks>
    Protected WithEvents return_url As Global.System.Web.UI.HtmlControls.HtmlInputHidden

    '''<summary>
    '''show_url 控件。
    '''</summary>
    '''<remarks>
    '''自动生成的字段。
    '''若要进行修改，请将字段声明从设计器文件移到代码隐藏文件。
    '''</remarks>
    Protected WithEvents show_url As Global.System.Web.UI.HtmlControls.HtmlInputHidden
End Class
